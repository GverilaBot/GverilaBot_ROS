/************************************************************************************//**
* \file         asciiprotocol.h
* \brief        ASCII protocol module header file.
* \ingroup      AsciiProtocol
* \internal
*----------------------------------------------------------------------------------------
*                          C O P Y R I G H T
*----------------------------------------------------------------------------------------
*   Copyright (c) 2017  by Feaser    http://www.feaser.com    All rights reserved
*
*----------------------------------------------------------------------------------------
*                            L I C E N S E
*----------------------------------------------------------------------------------------
* This file is part of OpenBLT. OpenBLT is free software: you can redistribute it and/or
* modify it under the terms of the GNU General Public License as published by the Free
* Software Foundation, either version 3 of the License, or (at your option) any later
* version.
*
* OpenBLT is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
* without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
* PURPOSE. See the GNU General Public License for more details.
*
* You have received a copy of the GNU General Public License along with OpenBLT. It
* should be located in ".\Doc\license.html". If not, contact Feaser to obtain a copy.
*
* \endinternal
****************************************************************************************/
/************************************************************************************//**
* \defgroup   ASCII protocol
* \brief      This module implements ASCII communication protocol that can be linked  to
*             the Session module. 
* \ingroup    Session
* \details
* This ASCII protocol module contains functionality according to the ODrive ASCII
* protocol. Note that only those parts of the ASCII functionality are implemented  that
* are applicable. 
****************************************************************************************/
#ifndef ASCIIPROTOCOL_H
#define ASCIIPROTOCOL_H

#ifdef __cplusplus
extern "C" {
#endif

/****************************************************************************************
* Macro definitions
****************************************************************************************/
/** \brief Total number of bytes in a PC<->ODrive data packet. It should be at least
 *         equal or larger than that the largest command string.
 */
#define ASCII_PACKET_SIZE_MAX   (255u)
  
  
/****************************************************************************************
* Type definitions
****************************************************************************************/
/** \brief ASCII transport layer packet type. */
typedef struct t_ascii_transport_packet
{
  uint8_t data[ASCII_PACKET_SIZE_MAX];           /**< Packet data.                     */
  uint8_t len;                                   /**< Packet length.                   */
} tAsciiTransportPacket;

/** \brief ASCII transport layer. */
typedef struct t_ascii_transport
{
  /** \brief Initialization of the ASCII transport layer. */
  void (*Init) (void const * settings);
  /** \brief Termination the ASCII transport layer. */
  void (*Terminate) (void);
  /** \brief Connects the ASCII transport layer. */
  bool (*Connect) (void);
  /** \brief Disconnects the ASCII transport layer. */
  void (*Disconnect) (void);
  /** \brief Sends an ASCII packet and waits for the response to come back. */
  bool (*SendPacket) (tAsciiTransportPacket const * txPacket, 
                      tAsciiTransportPacket * rxPacket, uint16_t timeout);
} tAsciiProtocolTransport;

/** \brief ASCII protocol specific settings. */
typedef struct t_ascii_loader_settings
{
  /** \brief Command response timeout in milliseconds. */
  uint16_t timeout;
  /** \brief Pointer to the transport layer to use during protocol communications. */
  tAsciiProtocolTransport const * transport;
  /** \brief Pointer to the settings for the transport layer. */
  void const * transportSettings;
} tAsciiProtocolSettings;


/****************************************************************************************
* Function prototypes
****************************************************************************************/
tSessionProtocol const * AsciiGetProtocol(void);

#ifdef __cplusplus
}
#endif

#endif /* ASCIIPROTOCOL_H */
/******************************* end of asciiprotocol.h ********************************/
