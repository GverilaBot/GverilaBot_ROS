/************************************************************************************//**
* \file         ODrive.c
* \brief        ODrive library source file.
* \ingroup      Library
* \internal
*----------------------------------------------------------------------------------------
*                          C O P Y R I G H T
*----------------------------------------------------------------------------------------
*   Copyright (c) 2017  by Feaser    http://www.feaser.com    All rights reserved
*
*----------------------------------------------------------------------------------------
*                            L I C E N S E
*----------------------------------------------------------------------------------------
* This file is part of OpenBLT. OpenBLT is free software: you can redistribute it and/or
* modify it under the terms of the GNU General Public License as published by the Free
* Software Foundation, either version 3 of the License, or (at your option) any later
* version.
*
* OpenBLT is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
* without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
* PURPOSE. See the GNU General Public License for more details.
*
* You have received a copy of the GNU General Public License along with OpenBLT. It
* should be located in ".\Doc\license.html". If not, contact Feaser to obtain a copy.
*
* \endinternal
****************************************************************************************/

/****************************************************************************************
* Include files
****************************************************************************************/
#include <assert.h>                         /* for assertions                          */
#include <stddef.h>                         /* for NULL declaration                    */
#include <stdbool.h>                        /* for boolean type                        */
#include "ODrive.h"                         /* ODrive library                          */
#include "util.h"                           /* Utility module                          */
#include "session.h"                        /* Communication session module            */
#include "asciiprotocol.h"                  /* ASCII protocl module                    */
#include "tpuart.h"                         /* UART transport layer                    */

/****************************************************************************************
* Macro definitions
****************************************************************************************/
/** \brief The version number of the library as an integer. The number has two digits for
 *         major-, minor-, and patch-version. Version 1.05.12 would for example be 10512.
 */
#define LIBODRIVE_VERSION_NUMBER   (10304u)

/** \brief The version number of the library as a null-terminated string. */
#define LIBODRIVE_VERSION_STRING   "1.03.04"


/****************************************************************************************
* Local constant declarations
****************************************************************************************/
/** \brief Constant null-terminated string with the version number of the library. */
char const libODriveVersionString[] = LIBODRIVE_VERSION_STRING;


/****************************************************************************************
*             V E R S I O N   I N F O R M A T I O N
****************************************************************************************/
/************************************************************************************//**
** \brief     Obtains the version number of the library as an integer. The number has two
**            digits for major-, minor-, and patch-version. Version 1.05.12 would for
**            example return 10512.
** \return    Library version number as an integer.
**
****************************************************************************************/
LIBODRIVE_EXPORT uint32_t LibODriveVersionGetNumber(void)
{
  return LIBODRIVE_VERSION_NUMBER;
} /*** end of LibODriveVersionGetNumber ***/


/************************************************************************************//**
** \brief     Obtains the version number of the library as a null-terminated string.
**            Version 1.05.12 would for example return "1.05.12".
** \return    Library version number as a null-terminated string.
**
****************************************************************************************/
LIBODRIVE_EXPORT char const * LibODriveVersionGetString(void)
{
  return LIBODRIVE_VERSION_STRING;
} /*** end of LibODriveVersionGetString ***/


/****************************************************************************************
*             S E S S I O N   /   T R A N S P O R T   L A Y E R S
****************************************************************************************/
/************************************************************************************//**
** \brief     Initializes the firmware update session for a specific communication
**            protocol and transport layer. This function is typically called once at
**            the start of the firmware update.
** \param     sessionType The communication protocol to use for this session. It should
**            be a LIBODRIVE_SESSION_xxx value.
** \param     sessionSettings Pointer to a structure with communication protocol specific
**            settings.
** \param     transportType The transport layer to use for the specified communication
**            protocol. It should be a LIBODRIVE_TRANSPORT_xxx value.
** \param     transportSettings Pointer to a structure with transport layer specific
**            settings.
**
****************************************************************************************/
LIBODRIVE_EXPORT void LibODriveSessionInit(uint32_t sessionType,
                                             void const * sessionSettings,
                                             uint32_t transportType,
                                             void const * transportSettings)
{
  /* Check parameters. Note that the settings-pointers are allowed to be NULL in case
   * no additional settings are needed for the specified session or transport type.
   */
  assert(sessionType == LIBODRIVE_SESSION_ASCII);
  assert( (transportType == LIBODRIVE_TRANSPORT_RS232) || \
          (transportType == LIBODRIVE_TRANSPORT_CAN)   || \
          (transportType == LIBODRIVE_TRANSPORT_USB)   || \
          (transportType == LIBODRIVE_TRANSPORT_NET) );
  
  /* Initialize the correct session. */
  if (sessionType == LIBODRIVE_SESSION_ASCII) /*lint !e774 */
  {
    /* Verify settingsSettings parameter because the ASCII protocol requires them. */
    assert(sessionSettings != NULL);
    /* Only continue if the settingsSettings parameter is valid. */
    if (sessionSettings != NULL) /*lint !e774 */
    {
      /* Cast session settings to the correct type. */
      tLibODriveSessionSettingsAscii * SessionSettingsAsciiPtr;
      SessionSettingsAsciiPtr = ((tLibODriveSessionSettingsAscii *)sessionSettings);
      /* Convert session settings to the format supported by the ASCII protocol module.*/
      tAsciiProtocolSettings asciiProtocolSettings;
      asciiProtocolSettings.timeout = SessionSettingsAsciiPtr->timeout;
      asciiProtocolSettings.transport = NULL;
      asciiProtocolSettings.transportSettings = NULL;
      /* Link the correct transport layer. */
      if (transportType == LIBODRIVE_TRANSPORT_RS232)
      {
        /* Verify transportSettings parameters because UART transport layer requires
         * them.
         */
        assert(transportSettings != NULL);
        /* Only continue if the transportSettings parameter is valid. */
        if (transportSettings != NULL) /*lint !e774 */
        {
          /* Cast transport settings to the correct type. */
          tLibODriveTransportSettingsRs232 * libODriveTransportSettingsRs232Ptr;
          libODriveTransportSettingsRs232Ptr =
            (tLibODriveTransportSettingsRs232 * )transportSettings;
          /* Convert transport settings to the format supported by the CAN transport
           * layer. It was made static to make sure it doesn't get out of scope when
           * used in asciiProtocolSettings.
           */
          static tTpUartSettings UartSettings;
          UartSettings.baudrate = libODriveTransportSettingsRs232Ptr->baudrate;
          UartSettings.portname = libODriveTransportSettingsRs232Ptr->portName;
          /* Store transport layer settings in the ASCII protocol settings. */
          asciiProtocolSettings.transportSettings = &UartSettings;
          /* Link the transport layer to the ASCII protocol settings. */
          asciiProtocolSettings.transport = TpUartGetTransport();
        }
      }
      else if (transportType == LIBODRIVE_TRANSPORT_CAN)
      {
        ///* Verify transportSettings parameters because the XCP CAN transport layer 
        // * requires them.
        // */
        //assert(transportSettings != NULL);
        ///* Only continue if the transportSettings parameter is valid. */
        //if (transportSettings != NULL) /*lint !e774 */
        //{
        //  /* Cast transport settings to the correct type. */
        //  tBltTransportSettingsXcpV10Can * bltTransportSettingsXcpV10CanPtr;
        //  bltTransportSettingsXcpV10CanPtr =
        //    (tBltTransportSettingsXcpV10Can *)transportSettings;
        //  /* Convert transport settings to the format supported by the XCP CAN transport
        //    * layer. It was made static to make sure it doesn't get out of scope when
        //    * used in asciiProtocolSettings.
        //    */
        //  static tXcpTpCanSettings xcpTpCanSettings;
        //  xcpTpCanSettings.device = bltTransportSettingsXcpV10CanPtr->deviceName;
        //  xcpTpCanSettings.channel = bltTransportSettingsXcpV10CanPtr->deviceChannel;
        //  xcpTpCanSettings.baudrate = bltTransportSettingsXcpV10CanPtr->baudrate;
        //  xcpTpCanSettings.transmitId = bltTransportSettingsXcpV10CanPtr->transmitId;
        //  xcpTpCanSettings.receiveId = bltTransportSettingsXcpV10CanPtr->receiveId;
        //  xcpTpCanSettings.useExtended = (bltTransportSettingsXcpV10CanPtr->useExtended != 0);
        //  /* Store transport layer settings in the XCP loader settings. */
        //  asciiProtocolSettings.transportSettings = &xcpTpCanSettings;
        //  /* Link the transport layer to the XCP loader settings. */
        //  asciiProtocolSettings.transport = XcpTpCanGetTransport();
        //}
      }
      else if (transportType == LIBODRIVE_TRANSPORT_USB)
      {
        ///* Store transport layer settings in the XCP loader settings. */
        //asciiProtocolSettings.transportSettings = NULL;
        ///* Link the transport layer to the XCP loader settings. */
        //asciiProtocolSettings.transport = XcpTpUsbGetTransport();
      }
      else if (transportType == LIBODRIVE_TRANSPORT_NET)
      {
        ///* Verify transportSettings parameters because the XCP NET transport layer
        // * requires them.
        // */
        //assert(transportSettings != NULL);
        ///* Only continue if the transportSettings parameter is valid. */
        //if (transportSettings != NULL) /*lint !e774 */
        //{
        //  /* Cast transport settings to the correct type. */
        //  tBltTransportSettingsXcpV10Net * bltTransportSettingsXcpV10NetPtr;
        //  bltTransportSettingsXcpV10NetPtr =
        //    (tBltTransportSettingsXcpV10Net * )transportSettings;
        //  /* Convert transport settings to the format supported by the XCP NET transport
        //   * layer. It was made static to make sure it doesn't get out of scope when
        //   * used in asciiProtocolSettings.
        //   */
        //  static tXcpTpNetSettings xcpTpNetSettings;
        //  xcpTpNetSettings.address = bltTransportSettingsXcpV10NetPtr->address;
        //  xcpTpNetSettings.port = bltTransportSettingsXcpV10NetPtr->port;
        //  /* Store transport layer settings in the XCP loader settings. */
        //  asciiProtocolSettings.transportSettings = &xcpTpNetSettings;
        //  /* Link the transport layer to the XCP loader settings. */
        //  asciiProtocolSettings.transport = XcpTpNetGetTransport();
        //}
      }
      /* Perform actual session initialization. */
      SessionInit(AsciiGetProtocol(), &asciiProtocolSettings);
    }
  }
} /*** end of LibODriveSessionInit ***/


/************************************************************************************//**
** \brief     Terminates the firmware update session. This function is typically called
**            once at the end of the firmware update.
**
****************************************************************************************/
LIBODRIVE_EXPORT void LibODriveSessionTerminate(void)
{
  /* Terminate the session. */
  SessionTerminate();
} /*** end of LibODriveSessionTerminate ***/


/************************************************************************************//**
** \brief     Starts the firmware update session. This is were the library attempts to
**            activate and connect with the bootloader running on the target, through
**            the transport layer that was specified during the session's initialization.
** \return    LIBODRIVE_RESULT_OK if successful, LIBODRIVE_RESULT_ERROR_xxx otherwise.
**
****************************************************************************************/
LIBODRIVE_EXPORT uint32_t LibODriveSessionStart(void)
{
  uint32_t result = LIBODRIVE_RESULT_ERROR_GENERIC;

  /* Start the session. */
  if (SessionStart())
  {
    result = LIBODRIVE_RESULT_OK;
  }
  /* Give the result back to the caller. */
  return result;
} /*** end of LibODriveSessionStart ***/


/************************************************************************************//**
** \brief     Stops the firmware update session. This is there the library disconnects
**            the transport layer as well.
**
****************************************************************************************/
LIBODRIVE_EXPORT void LibODriveSessionStop(void)
{
  /* Stop the session. */
  SessionStop();
} /*** end of LibODriveSessionStop ***/


/************************************************************************************//**
** \brief     Send some data to the target.
** \param     txData Pointer to the byte array with data to write.
** \param     txLen The number of bytes in the data buffer that should be written.
** \param     rxData Pointer to the byte array with data read.
** \param     rxLen Pointer to the number of bytes read and written in the rxData buffer.
** \return    BLT_RESULT_OK if successful, BLT_RESULT_ERROR_xxx otherwise.
**
****************************************************************************************/
LIBODRIVE_EXPORT uint32_t LibODriveSessionWriteData(uint8_t const * txData,
                                                    uint32_t txLen,
                                                    uint8_t * rxData, uint32_t * rxLen)
{
  uint32_t result = LIBODRIVE_RESULT_ERROR_GENERIC;

  /* Check parameters. */
  assert(txData != NULL);
  assert(txLen > 0);
  
  /* Only continue if the parameters are valid. */ 
  if ( (txData != NULL) && (txLen > 0) ) /*lint !e774 */
  {
    /* Pass the request on to the session module. */
    if (SessionWriteData(txData, txLen, rxData, rxLen))
    {
      result = LIBODRIVE_RESULT_OK;
    }
  }
  /* Give the result back to the caller. */
  return result;
} /*** end of LibODriveSessionWriteData ***/


/************************************************************************************//**
** \brief     Request some data from the target to be read. The data is stored in the
**            data byte array to which the pointer was specified.
** \param     len The number of bytes to upload from the target and store in the data 
**            buffer.
** \param     data Pointer to the byte array where the uploaded data should be stored.
** \return    BLT_RESULT_OK if successful, BLT_RESULT_ERROR_xxx otherwise.
**
****************************************************************************************/
LIBODRIVE_EXPORT uint32_t LibODriveSessionReadData(uint32_t len, uint8_t * data)
{
  uint32_t result = LIBODRIVE_RESULT_ERROR_GENERIC;

  /* Check parameters. */
  assert(data != NULL);
  assert(len > 0);

  /* Only continue if the parameters are valid. */
  if ( (data != NULL) && (len > 0) ) /*lint !e774 */
  {
    /* Pass the request on to the session module. */
    if (SessionReadData(len, data))
    {
      result = LIBODRIVE_RESULT_OK;
    }
  }
  /* Give the result back to the caller. */
  return result;
} /*** end of LibODriveSessionReadData ***/


/****************************************************************************************
*             G E N E R I C   U T I L I T I E S
****************************************************************************************/
/************************************************************************************//**
** \brief     Calculates a 16-bit CRC value over the specified data.
** \param     data Array with bytes over which the CRC16 should be calculated.
** \param     len Number of bytes in the data array.
** \return    The 16-bit CRC value.
**
****************************************************************************************/
LIBODRIVE_EXPORT uint16_t LibODriveUtilCrc16Calculate(uint8_t const * data, uint32_t len)
{
  uint16_t result = 0;
  
  /* Check parameters. */
  assert(data != NULL);
  assert(len > 0);

  /* Only continue if parameters are valid. */
  if ( (data != NULL) && (len > 0) ) /*lint !e774 */
  {
    /* Perform checksum calculation. */
    result = UtilChecksumCrc16Calculate(data, len);
  }
  /* Give the result back to the caller. */
  return result;
} /*** end of LibODriveUtilCrc16Calculate ***/


/************************************************************************************//**
** \brief     Calculates a 32-bit CRC value over the specified data.
** \param     data Array with bytes over which the CRC32 should be calculated.
** \param     len Number of bytes in the data array.
** \return    The 32-bit CRC value.
**
****************************************************************************************/
LIBODRIVE_EXPORT uint32_t LibODriveUtilCrc32Calculate(uint8_t const * data, uint32_t len)
{
  uint32_t result = 0;
  
  /* Check parameters. */
  assert(data != NULL);
  assert(len > 0);

  /* Only continue if parameters are valid. */
  if ( (data != NULL) && (len > 0) ) /*lint !e774 */
  {
    /* Perform checksum calculation. */
    result = UtilChecksumCrc32Calculate(data, len);
  }
  /* Give the result back to the caller. */
  return result;
} /*** end of LibODriveUtilCrc32Calculate ***/


/************************************************************************************//**
** \brief     Get the system time in milliseconds.
** \return    Time in milliseconds.
**
****************************************************************************************/
LIBODRIVE_EXPORT uint32_t LibODriveUtilTimeGetSystemTime(void)
{
  uint32_t result;
  
  /* Pass the request on to the utility module. */
  result = UtilTimeGetSystemTimeMs();
  /* Give the result back to the caller. */
  return result;
} /*** end of LibODriveUtilTimeGetSystemTime ***/

/************************************************************************************//**
** \brief     Performs a delay of the specified amount of milliseconds.
** \param     delay Delay time in milliseconds.
**
****************************************************************************************/
LIBODRIVE_EXPORT void LibODriveUtilTimeDelayMs(uint16_t delay)
{
  /* Pass the request on to the utility module. */
  UtilTimeDelayMs(delay);
} /*** end of LibODriveUtilTimeDelayMs ***/


/************************************************************************************//**
** \brief     Encrypts the len-bytes in the specified data-array, using the specified
**            256-bit (32 bytes) key. The results are written back into the same array.
** \param     data Pointer to the byte array with data to encrypt. The encrypted bytes
**            are stored in the same array.
** \param     len The number of bytes in the data-array to encrypt. It must be a multiple
**            of 16, as this is the AES256 minimal block size.
** \param     key The 256-bit encryption key as a array of 32 bytes.
** \return    LIBODRIVE_RESULT_OK if successful, LIBODRIVE_RESULT_ERROR_xxx otherwise.
**
****************************************************************************************/
LIBODRIVE_EXPORT uint32_t LibODriveUtilCryptoAes256Encrypt(uint8_t * data, uint32_t len,
                                                      uint8_t const * key)
{
  uint32_t result = LIBODRIVE_RESULT_ERROR_GENERIC;

  /* Check parameters */
  assert(data != NULL);
  assert(key != NULL);

  /* Only continue with valid parameters. Also add a block size check for 'len'. */
  if ( (data != NULL) && (key != NULL) && ((len % 16u) == 0) ) /*lint !e774 */
  {
    /* Pass the request on to the utility module. */
    if (UtilCryptoAes256Encrypt(data, len, key))
    {
      result = LIBODRIVE_RESULT_OK;
    }
  }
  /* Give the result back to the caller. */
  return result;
} /*** end of LibODriveUtilCryptoAes256Encrypt ***/


/************************************************************************************//**
** \brief     Decrypts the len-bytes in the specified data-array, using the specified 256-
**            bit (32 bytes) key. The results are written back into the same array.
** \param     data Pointer to the byte array with data to decrypt. The decrypted bytes
**            are stored in the same array.
** \param     len The number of bytes in the data-array to decrypt. It must be a multiple
**            of 16, as this is the AES256 minimal block size.
** \param     key The 256-bit decryption key as a array of 32 bytes.
** \return    LIBODRIVE_RESULT_OK if successful, LIBODRIVE_RESULT_ERROR_xxx otherwise.
**
****************************************************************************************/
LIBODRIVE_EXPORT uint32_t LibODriveUtilCryptoAes256Decrypt(uint8_t * data, uint32_t len,
                                                      uint8_t const * key)
{
  uint32_t result = LIBODRIVE_RESULT_ERROR_GENERIC;

  /* Check parameters */
  assert(data != NULL);
  assert(key != NULL);

  /* Only continue with valid parameters. Also add a block size check for 'len'. */
  if ( (data != NULL) && (key != NULL) && ((len % 16u) == 0) ) /*lint !e774 */
  {
    /* Pass the request on to the utility module. */
    if (UtilCryptoAes256Decrypt(data, len, key))
    {
      result = LIBODRIVE_RESULT_OK;
    }
  }
  /* Give the result back to the caller. */
  return result;
} /*** end of LibODriveUtilCryptoAes256Decrypt ***/


/*********************************** end of ODrive.c ***********************************/
