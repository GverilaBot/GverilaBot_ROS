"""
Package **openblt** is a python wrapper for the OpenBLT Host Library (`LibOpenBLT <https://www.feaser.com/openblt/doku.php?id=manual:libopenblt>`_).  

Have a look at the function headers inside openblt.lib for details on how to call the functions, including examples.
"""
__docformat__ = 'reStructuredText'
# ***************************************************************************************
#  File Name: __init__.py
#
# ---------------------------------------------------------------------------------------
#                           C O P Y R I G H T
# ---------------------------------------------------------------------------------------
#    Copyright (c) 2018  by Feaser    http://www.feaser.com    All rights reserved
#
# ---------------------------------------------------------------------------------------
#                             L I C E N S E
# ---------------------------------------------------------------------------------------
#  This file is part of OpenBLT. OpenBLT is free software: you can redistribute it and/or
#  modify it under the terms of the GNU General Public License as published by the Free
#  Software Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  OpenBLT is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
#  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
#  PURPOSE. See the GNU General Public License for more details.
#
#  You have received a copy of the GNU General Public License along with OpenBLT. It
#  should be located in ".\Doc\license.html". If not, contact Feaser to obtain a copy.
#
# ***************************************************************************************


# ***************************************************************************************
#  Imports
# ***************************************************************************************
from libODrive.lib import LIBODRIVE_RESULT_OK
from libODrive.lib import LIBODRIVE_RESULT_ERROR_GENERIC


# ***************************************************************************************
#              V E R S I O N   I N F O R M A T I O N
# ***************************************************************************************
from libODrive.lib import version_get_number
from libODrive.lib import version_get_string


# ***************************************************************************************
#              S E S S I O N   /   T R A N S P O R T   L A Y E R S
# ***************************************************************************************
from libODrive.lib import LIBODRIVE_SESSION_ASCII
from libODrive.lib import LIBODRIVE_TRANSPORT_RS232
from libODrive.lib import LIBODRIVE_TRANSPORT_CAN
from libODrive.lib import LIBODRIVE_TRANSPORT_USB
from libODrive.lib import LIBODRIVE_TRANSPORT_NET
from libODrive.lib import LibODriveSessionSettingsAscii
from libODrive.lib import LibODriveTransportSettingsRs232
from libODrive.lib import LibODriveTransportSettingsCan
from libODrive.lib import LibODriveTransportSettingsNet
from libODrive.lib import session_init
from libODrive.lib import session_terminate
from libODrive.lib import session_start
from libODrive.lib import session_stop
from libODrive.lib import session_write_data
from libODrive.lib import session_read_data


# ***************************************************************************************
#              G E N E R I C   U T I L I T I E S
# ***************************************************************************************
from libODrive.lib import util_crc16_calculate
from libODrive.lib import util_crc32_calculate
from libODrive.lib import util_time_get_system_time
from libODrive.lib import util_time_delay_ms
from libODrive.lib import util_crypto_aes256_encrypt
from libODrive.lib import util_crypto_aes256_decrypt


# ********************************* end of __init__.py **********************************
