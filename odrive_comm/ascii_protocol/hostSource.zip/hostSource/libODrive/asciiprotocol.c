/************************************************************************************//**
* \file         asciiprotocol.c
* \brief        ASCII protocol module header file.
* \ingroup      AsciiProtocol
* \internal
*----------------------------------------------------------------------------------------
*                          C O P Y R I G H T
*----------------------------------------------------------------------------------------
*   Copyright (c) 2017  by Feaser    http://www.feaser.com    All rights reserved
*
*----------------------------------------------------------------------------------------
*                            L I C E N S E
*----------------------------------------------------------------------------------------
* This file is part of OpenBLT. OpenBLT is free software: you can redistribute it and/or
* modify it under the terms of the GNU General Public License as published by the Free
* Software Foundation, either version 3 of the License, or (at your option) any later
* version.
*
* OpenBLT is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
* without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
* PURPOSE. See the GNU General Public License for more details.
*
* You have received a copy of the GNU General Public License along with OpenBLT. It
* should be located in ".\Doc\license.html". If not, contact Feaser to obtain a copy.
*
* \endinternal
****************************************************************************************/

/****************************************************************************************
* Include files
****************************************************************************************/
#include <assert.h>                         /* for assertions                          */
#include <stdint.h>                         /* for standard integer types              */
#include <stddef.h>                         /* for NULL declaration                    */
#include <stdbool.h>                        /* for boolean type                        */
#include <stdlib.h>                         /* for standard library                    */
#include <string.h>                         /* for string library                      */
#include "session.h"                        /* Communication session module            */
#include "asciiprotocol.h"                  /* ASCII protocol module                   */


/****************************************************************************************
* Macro definitions
****************************************************************************************/
/** \brief Number of retries to connect to the target. */
#define ASCIIPROTOCOL_CONNECT_RETRIES    (5u)


/****************************************************************************************
* Function prototypes
****************************************************************************************/
/* Protocol functions for linking to the session module. */
static void AsciiProtocolInit(void const * settings);
static void AsciiProtocolTerminate(void);
static bool AsciiProtocolStart(void);
static void AsciiProtocolStop(void);
static bool AsciiProtocolWriteData(uint8_t const * txData, uint32_t txLen,
                                   uint8_t * rxData, uint32_t * rxLen);
/* General module specific utility functions. */
static void AsciiProtocolSetOrderedLong(uint32_t value, uint8_t *data);
static uint16_t AsciiProtocolGetOrderedWord(uint8_t const * data);


/****************************************************************************************
* Local constant declarations
****************************************************************************************/
/** \brief Protocol structure filled with ASCII protocol specifics. */
static const tSessionProtocol asciiProtocol =
{
  .Init = AsciiProtocolInit,
  .Terminate = AsciiProtocolTerminate,
  .Start = AsciiProtocolStart,
  .Stop = AsciiProtocolStop,
  .WriteData = AsciiProtocolWriteData,
  .ReadData = NULL
};


/****************************************************************************************
* Local data declarations
****************************************************************************************/
/** \brief The settings that should be used by the ASCII protocol. */
static tAsciiProtocolSettings asciiProtocolSettings;

/** \brief Flag to keep track of the connection status. */
static bool asciiConnected;

/** \brief Store the byte ordering of the target. */
static bool targetIsIntel;


/***********************************************************************************//**
** \brief     Obtains a pointer to the protocol structure, so that it can be linked to 
**            the communication session module.
** \return    Pointer to protocol structure.
**
****************************************************************************************/
tSessionProtocol const * AsciiGetProtocol(void)
{
  return &asciiProtocol;
} /*** end of AsciiGetProtocol ***/


/************************************************************************************//**
** \brief     Initializes the protocol module.
** \param     settings Pointer to the structure with protocol settings.
**
****************************************************************************************/
static void AsciiProtocolInit(void const * settings)
{
  /* Initialize locals. */
  asciiConnected = false;
  targetIsIntel = false;

  /* Reset the ASCII protocol session layer settings. */
  asciiProtocolSettings.transport = NULL;
  asciiProtocolSettings.transportSettings = NULL;

  /* Check parameter. */
  assert(settings != NULL);
  /* Only continue with valid parameter. */
  if (settings != NULL) /*lint !e774 */
  {
    /* shallow copy the ASCII protocol settings for later usage */
    asciiProtocolSettings = *(tAsciiProtocolSettings *)settings;
    /* Check that a valid transport layer was specified. */
    assert(asciiProtocolSettings.transport != NULL);
    /* Only access the transport layer if it is valid. */
    if (asciiProtocolSettings.transport != NULL) /*lint !e774 */
    {
      /* Initialize the transport layer. */
      asciiProtocolSettings.transport->Init(asciiProtocolSettings.transportSettings);
    }
    /* Invalidate the transportSettings as it is probably no longer valid outside this
     * function scope and should also not be used anymore.
     */
    asciiProtocolSettings.transportSettings = NULL;
  }
} /*** end of AsciiProtocolInit ***/


/************************************************************************************//**
** \brief     Terminates the protocol module.
**
****************************************************************************************/
static void AsciiProtocolTerminate(void)
{
  /* Make sure a valid transport layer is linked. */
  assert(asciiProtocolSettings.transport != NULL);
  
  /* Only continue with a valid transport layer. */
  if (asciiProtocolSettings.transport != NULL) /*lint !e774 */
  {
    /* Terminate the transport layer. */
    asciiProtocolSettings.transport->Terminate();
    /* Unlink the transport layer. */
    asciiProtocolSettings.transport = NULL;
  }
  /* Reset the ASCII protocol session layer settings. */
  asciiProtocolSettings.transport = NULL;
  asciiProtocolSettings.transportSettings = NULL;
} /*** end of AsciiProtocolTerminate ***/


/************************************************************************************//**
** \brief     Starts the connection with the target. This is where the connection with
**            the target is made.
** \return    True if successful, false otherwise.
**
****************************************************************************************/
static bool AsciiProtocolStart(void)
{
  bool result = false;
  uint8_t retryCnt;

  /* Make sure a valid transport layer is linked. */
  assert(asciiProtocolSettings.transport != NULL);
  
  /* Only continue with a valid transport layer. */
  if (asciiProtocolSettings.transport != NULL) /*lint !e774 */
  {
    /* Make sure the session is stopped before starting a new one. */
    AsciiProtocolStop();
    /* Init the result value to okay and only set it to error when a problem occurred. */
    result = true;
    /* Connect to the target with a finite amount of retries. */
    if (result)
    {
      for (retryCnt = 0; retryCnt < ASCIIPROTOCOL_CONNECT_RETRIES; retryCnt++)
      {
        /* Connect the transport layer. */
        if (asciiProtocolSettings.transport->Connect())
        {
          /* Update connection state. */
          asciiConnected = true;
          /* Connected so no need to retry. */
          break;
        }
      }
      /* Check if a connection with the target could be made within the finite amount
       * of retries.
       */
      if (!asciiConnected)
      {
        /* Disconnect the transport layer again. */
        asciiProtocolSettings.transport->Disconnect();
        /* Update the result. */
        result = false;
      }
    }
  }   
  /* Give the result back to the caller. */
  return result;
} /*** end of AsciiProtocolStart ***/


/************************************************************************************//**
** \brief    Stops the connection with the target. After this the connection with the
**           target is severed.
**
****************************************************************************************/
static void AsciiProtocolStop(void)
{
  /* Make sure a valid transport layer is linked. */
  assert(asciiProtocolSettings.transport != NULL);
  
  /* Only continue with a valid transport layer and if actually connected. */
  if ( (asciiProtocolSettings.transport != NULL) && (asciiConnected) ) /*lint !e774 */
  {
    /* Disconnect the transport layer. */
    asciiProtocolSettings.transport->Disconnect();
    /* Reset connection status. */
    asciiConnected = false;
  }
} /*** end of AsciiProtocolStop ***/


/************************************************************************************//**
** \brief     Send some data to the target.
** \param     txData Pointer to the byte array with data to write.
** \param     txLen The number of bytes in the data buffer that should be written.
** \param     rxData Pointer to the byte array with data read.
** \param     rxLen Pointer to the number of bytes read and written in the rxData buffer.
** \return    True if successful, false otherwise.
**
****************************************************************************************/
static bool AsciiProtocolWriteData(uint8_t const * txData, uint32_t txLen,
                                   uint8_t * rxData, uint32_t * rxLen)
{
  bool result = false;
  uint16_t count = 0;
  tAsciiTransportPacket cmdPacket;
  tAsciiTransportPacket resPacket;
  
  /* Check parameters. */
  assert(txData != NULL);
  assert(txLen > 0);
  /* Make sure a valid transport layer is linked. */
  assert(asciiProtocolSettings.transport != NULL);
  
  /* Only continue if the parameters are valid. */
  if ( (txData != NULL) && (txLen > 0) && (asciiProtocolSettings.transport != NULL) &&
       (asciiConnected) )                                                 /*lint !e774 */
  {
    /* Init the result value to okay and only set it to error when a problem occurred. */
    result = true;
    /* Prepare the command packet. */
    cmdPacket.len = 0;
    while ( txLen-- > 0 )
    {
      count = cmdPacket.len++;
      cmdPacket.data[count] = txData[count];
    }
    /* Send the packet. */
    if (!asciiProtocolSettings.transport->SendPacket(&cmdPacket, &resPacket,
                                                     asciiProtocolSettings.timeout))
    {
      /* Could not send packet or receive response within the specified timeout. */
      result = false;
    }
    /* Only continue if a response was received. */
    if (result)
    {
      /* Check if the response was valid. */
      if ( resPacket.len > 0 )
      {
        if ( (rxData != NULL) && (rxLen != NULL) )
        {
          *rxLen = 0;
          while ( resPacket.len-- > 0 )
          {
            count = (*rxLen)++;
            rxData[count] = resPacket.data[count];
          }
        }
      }
      else
      {
        /* Not a valid or positive response. */
        result = false;
      }
    }
  }
  /* Give the result back to the caller. */
  return result;
} /*** end of AsciiProtocolWriteData ***/


/************************************************************************************//**
** \brief     Stores a 32-bit value into a byte buffer taking into account Intel
**            or Motorola byte ordering.
** \param     value The 32-bit value to store in the buffer.
** \param     data Array to the buffer for storage.
**
****************************************************************************************/
static void AsciiProtocolSetOrderedLong(uint32_t value, uint8_t *data)
{
  /* Check parameters. */
  assert(data != NULL);
  
  /* Only continue with valid parameters. */
  if (data != NULL) /*lint !e774 */
  {
    if (targetIsIntel)
    {
      data[3] = (uint8_t)(value >> 24);
      data[2] = (uint8_t)(value >> 16);
      data[1] = (uint8_t)(value >>  8);
      data[0] = (uint8_t)value;
    }
    else
    {
      data[0] = (uint8_t)(value >> 24);
      data[1] = (uint8_t)(value >> 16);
      data[2] = (uint8_t)(value >>  8);
      data[3] = (uint8_t)value;
    }
  }
} /*** end of AsciiProtocolSetOrderedLong ***/


/************************************************************************************//**
** \brief     Obtains a 16-bit value from a byte buffer taking into account Intel
**            or Motorola byte ordering.
** \param     data Array to the buffer with the word value stored as bytes.
** \return    The 16-bit value.
**
****************************************************************************************/
static uint16_t AsciiProtocolGetOrderedWord(uint8_t const * data)
{
  uint16_t result = 0;

  /* Check parameters. */
  assert(data != NULL);

  /* Only continue with valid parameters. */
  if (data != NULL) /*lint !e774 */
  {
    if (targetIsIntel)
    {
      result |= (uint16_t)data[0];
      result |= (uint16_t)(data[1] << 8);
    }
    else
    {
      result |= (uint16_t)data[1];
      result |= (uint16_t)(data[0] << 8);
    }
  }
  /* Give the result back to the caller. */
  return result;
} /*** end of AsciiProtocolGetOrderedWord ***/


/********************************* end of asciiprotocol.c ******************************/
