/************************************************************************************//**
* \file         session.c
* \brief        Communication session module source file.
* \ingroup      Session
* \internal
*----------------------------------------------------------------------------------------
*                          C O P Y R I G H T
*----------------------------------------------------------------------------------------
*   Copyright (c) 2017  by Feaser    http://www.feaser.com    All rights reserved
*
*----------------------------------------------------------------------------------------
*                            L I C E N S E
*----------------------------------------------------------------------------------------
* This file is part of OpenBLT. OpenBLT is free software: you can redistribute it and/or
* modify it under the terms of the GNU General Public License as published by the Free
* Software Foundation, either version 3 of the License, or (at your option) any later
* version.
*
* OpenBLT is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
* without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
* PURPOSE. See the GNU General Public License for more details.
*
* You have received a copy of the GNU General Public License along with OpenBLT. It
* should be located in ".\Doc\license.html". If not, contact Feaser to obtain a copy.
*
* \endinternal
****************************************************************************************/

/****************************************************************************************
* Include files
****************************************************************************************/
#include <assert.h>                         /* for assertions                          */
#include <stdint.h>                         /* for standard integer types              */
#include <stddef.h>                         /* for NULL declaration                    */
#include <stdbool.h>                        /* for boolean type                        */
#include "session.h"                        /* Communication session module            */


/****************************************************************************************
* Local data declarations
****************************************************************************************/
/** \brief Pointer to the communication protocol that is linked. */
static tSessionProtocol const * protocolPtr;


/************************************************************************************//**
** \brief     Initializes the communication session module for the specified protocol.
** \param     protocol The session protocol module to link.
** \param     protocolSettings Pointer to structure with protocol specific settings.
**
****************************************************************************************/
void SessionInit(tSessionProtocol const * protocol, void const * protocolSettings)
{
  /* Check parameters. Note that the protocolSettings parameter is allowed to be NULL,
   * because not every protocol might need additional settings. 
   */
  assert(protocol != NULL);
  
  /* Link the protocol module. */
  protocolPtr = protocol;
  
  /* Initialize the protocol and pass on the settings pointer. */
  if (protocolPtr != NULL)
  {
    protocolPtr->Init(protocolSettings);
  }
} /*** end of SessionInit ***/


/************************************************************************************//**
** \brief     Terminates the communication session module.
**
****************************************************************************************/
void SessionTerminate(void)
{
  /* Terminate the linked protocol. */
  if (protocolPtr != NULL) 
  {
    protocolPtr->Terminate();
  }
  /* Unlink the protocol module. */
  protocolPtr = NULL;
} /*** end of SessionTerminate ***/


/************************************************************************************//**
** \brief     Starts the connection with the target. This is where the connection with
**            the target is made.
** \return    True if successful, false otherwise.
**
****************************************************************************************/
bool SessionStart(void)
{
  bool result = false;
  
  /* Pass the request on to the linked protocol module. */
  if (protocolPtr != NULL)
  {
    result = protocolPtr->Start();
  }
  /* Give the result back to the caller. */
  return result;
} /*** end of SessionStart ***/


/************************************************************************************//**
** \brief    Stops the connection with the target. After this the connection with the
**           target is severed.
**
****************************************************************************************/
void SessionStop(void)
{
  /* Pass the request on to the linked protocol module. */
  if (protocolPtr != NULL)
  {
    protocolPtr->Stop();
  }
} /*** end of SessionStop ***/


/************************************************************************************//**
** \brief     Send some data to the target.
** \param     txData Pointer to the byte array with data to write.
** \param     txLen The number of bytes in the data buffer that should be written.
** \param     rxData Pointer to the byte array with data read.
** \param     rxLen Pointer to the number of bytes read and written in the rxData buffer.
** \return    True if successful, false otherwise.
**
****************************************************************************************/
bool SessionWriteData(uint8_t const * txData, uint32_t txLen, uint8_t * rxData,
                      uint32_t * rxLen)
{
  bool result = false;

  /* Check parameters. */
  assert(txData != NULL);
  assert(txLen > 0);
  
  /* Only continue if the parameters are valid. */
  if ( (txData != NULL) && (txLen > 0) ) /*lint !e774 */
  {
    /* Pass the request on to the linked protocol module. */
    result = protocolPtr->WriteData(txData, txLen, rxData, rxLen);
  }
  /* Give the result back to the caller. */
  return result;
} /*** end of SessionWriteData ***/


/************************************************************************************//**
** \brief     Request some data from the target to be read. The data is stored in the
**            data byte array to which the pointer was specified.
** \param     data Pointer to the byte array where the uploaded data should be stored.
** \param     len The number of bytes to upload from the target and store in the data 
**            buffer.
** \return    True if successful, false otherwise.
**
****************************************************************************************/
bool SessionReadData(uint8_t * data, uint32_t len)
{
  bool result = false;

  /* Check parameters. */
  assert(data != NULL);
  assert(len > 0);
  
  /* Only continue if the parameters are valid. */
  if ( (data != NULL) && (len > 0) ) /*lint !e774 */
  {
    /* Pass the request on to the linked protocol module. */
    result = protocolPtr->ReadData(data, len);
  }
  /* Give the result back to the caller. */
  return result;
} /*** end of SessionReadData ***/


/*********************************** end of session.c **********************************/
