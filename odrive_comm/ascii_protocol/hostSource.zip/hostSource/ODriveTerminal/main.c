/************************************************************************************//**
* \file         main.c
* \brief        ODriveTerminal program source file.
* \internal
*----------------------------------------------------------------------------------------
*                          C O P Y R I G H T
*----------------------------------------------------------------------------------------
*   Copyright (c) 2017  by Feaser    http://www.feaser.com    All rights reserved
*
*----------------------------------------------------------------------------------------
*                            L I C E N S E
*----------------------------------------------------------------------------------------
* This file is part of OpenBLT. OpenBLT is free software: you can redistribute it and/or
* modify it under the terms of the GNU General Public License as published by the Free
* Software Foundation, either version 3 of the License, or (at your option) any later
* version.
*
* OpenBLT is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
* without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
* PURPOSE. See the GNU General Public License for more details.
*
* You have received a copy of the GNU General Public License along with OpenBLT. It 
* should be located in ".\Doc\license.html". If not, contact Feaser to obtain a copy.
* 
* \endinternal
****************************************************************************************/

/****************************************************************************************
* Include files
****************************************************************************************/
#include <assert.h>                         /* for assertions                          */
#include <stdint.h>                         /* for standard integer types              */
#include <stdbool.h>                        /* for boolean type                        */
#include <stdlib.h>                         /* for standard library                    */
#include <stdio.h>                          /* Standard I/O functions.                 */
#include <string.h>                         /* for string library                      */
#include "ODrive.h"                         /* ODrive library.                         */


/****************************************************************************************
* Macro definitions
****************************************************************************************/
/** \brief Program return code indicating that the program executed successfully. */
#define RESULT_OK                           (0)
/** \brief Program return code indicating that an error was detected when processing the
 *         command line parameters.
 */
#define RESULT_ERROR_COMMANDLINE            (1)

/* Macros for colored text on the output, if supported. */
#if defined (PLATFORM_LINUX)
#define OUTPUT_RESET                        "\033[0m"
#define OUTPUT_RED                          "\033[31m"
#define OUTPUT_GREEN                        "\033[32m"
#define OUTPUT_YELLOW                       "\033[33m"
#else
#define OUTPUT_RESET                        ""
#define OUTPUT_RED                          ""
#define OUTPUT_GREEN                        ""
#define OUTPUT_YELLOW                       ""
#endif


/****************************************************************************************
* Type definitions
****************************************************************************************/
/** \brief Type for program settings. */
typedef struct t_program_settings
{
  /** \brief Controls what gets written to the standard output. If set to false then all
   *         information is written. If set to true then only the most basic progress
   *         information is shows.
   */
  bool silentMode;
} tProgramSettings;


/****************************************************************************************
* Function prototypes
****************************************************************************************/
static void DisplayProgramInfo(void);
static void DisplayProgramUsage(void);
static void DisplaySessionInfo(uint32_t sessionType, void const * sessionSettings);
static void DisplayTransportInfo(uint32_t transportType, void const * transportSettings);
static void ExtractProgramSettingsFromCommandLine(int argc, char const * const argv[],
                                                  tProgramSettings * programSettings);
static uint32_t ExtractSessionTypeFromCommandLine(int argc, char const * const argv[]);
static void * ExtractSessionSettingsFromCommandLine(int argc, char const * const argv[],
                                                    uint32_t sessionType);
static uint32_t ExtractTransportTypeFromCommandLine(int argc, char const * const argv[]);
static void * ExtractTransportSettingsFromCommandLine(int argc,
                                                      char const * const argv[],
                                                      uint32_t transportType);
static char const * GetLineTrailerByResult(bool errorDetected);
static char const * GetLineTrailerByPercentage(uint8_t percentage);
static void ErasePercentageTrailer(void);


/************************************************************************************//**
** \brief     This is the program entry point.
** \param     argc Number of program arguments.
** \param     argv Array with program arguments.
** \return    Program return code. 0 for success, error code otherwise.
**
****************************************************************************************/
int main(int argc, char const * const argv[])
{
  int result = RESULT_OK;
  tProgramSettings appProgramSettings = { 0 };
  uint32_t appSessionType = 0;
  void * appSessionSettings = NULL;
  uint32_t appTransportType = 0;;
  void * appTransportSettings = NULL;
  
  /* -------------------- Display info ----------------------------------------------- */
  /* Check that at least enough command line arguments were specified. The first one is
   * always the name of the executable. Additionally, the firmware file must at least be
   * specified.
   */
  if (argc < 2)
  {
    /* Display program info */
    DisplayProgramInfo();
    /* Display program usage. */
    DisplayProgramUsage();
    /* Set error code. */
    result = RESULT_ERROR_COMMANDLINE;
  }
  
  /* -------------------- Process command line --------------------------------------- */
  if (result == RESULT_OK)
  {
    /* Extract program specific settings from the command line. */
    ExtractProgramSettingsFromCommandLine(argc, argv, &appProgramSettings);
    /* Extract the session type from the command line. */
    appSessionType = ExtractSessionTypeFromCommandLine(argc, argv);
    /* Extract the session type specific settings from the command line. */
    appSessionSettings = ExtractSessionSettingsFromCommandLine(argc, argv,
                                                               appSessionType);
    /* Extract the transport type from the command line. */
    appTransportType = ExtractTransportTypeFromCommandLine(argc, argv);
    /* Extract the transport type specific settings from the command line. */
    appTransportSettings = ExtractTransportSettingsFromCommandLine(argc, argv, 
                                                                   appTransportType);
    /* Check the settings that were detected so far.
     * Note that the transport settings are allowed to be NULL in case of 
     * LIBODRIVE_TRANSPORT_USB.
     */
    if ( (appSessionSettings == NULL) &&
         (appTransportType != LIBODRIVE_TRANSPORT_USB) )
    {
      /* Set error code. */
      result = RESULT_ERROR_COMMANDLINE;
    }
    if ((!appProgramSettings.silentMode))
    {
      /* Display program info */
      DisplayProgramInfo();
    }
    printf("Processing command line parameters..."); 
    printf("%s\n", GetLineTrailerByResult((bool)(result != RESULT_OK)));
  }
  
  /* -------------------- Display detected parameters -------------------------------- */
  if ( (result == RESULT_OK) && (!appProgramSettings.silentMode) )
  {
    /* Display session info. */
    DisplaySessionInfo(appSessionType, appSessionSettings);
    /* Display transport info. */
    DisplayTransportInfo(appTransportType, appTransportSettings);
  }
  
  /* -------------------- Session starting ------------------------------------------- */
  if (result == RESULT_OK)
  {
    /* Initialize the session. */
    printf("Connecting to target..."); (void)fflush(stdout);
    LibODriveSessionInit(appSessionType,appSessionSettings, 
                         appTransportType, appTransportSettings);
    /* Start the session. */
    if (LibODriveSessionStart() != LIBODRIVE_RESULT_OK)
    {
      printf("[" OUTPUT_YELLOW "TIMEOUT" OUTPUT_RESET "]\n");
      /* No response. Prompt the user to reset the system. */
      printf("Retrying to connect (reset system if this takes too long)...");
      (void)fflush(stdout);
      /* Now keep trying until we get a response. */
      while (LibODriveSessionStart() != LIBODRIVE_RESULT_OK)
      {
        /* Delay a bit to not pump up the CPU load. */
        LibODriveUtilTimeDelayMs(20);
      }
    }
    printf("%s\n", GetLineTrailerByResult((bool)false));
  }
  
  /* -------------------- Send command ----------------------------------------------- */
  if (result == RESULT_OK)
  {
    uint8_t line[256];
    line[0] = 0;
    uint32_t len = 0;
    
    printf("--------------------------------------------------------------------------\n");
    printf("Commands:\n");
    printf("  -> t motor destination\n");
    printf("  -> q motor position velocity_lim current_lim\n");
    printf("  -> p motor position velocity_ff current_ff\n");
    printf("  -> v motor velocity current_ff\n");
    printf("  -> c motor current\n");
    printf("  -> f motor\n");
    printf("  -> u motor\n");
    printf("  -> r [property]\n");
    printf("  -> w [property] [value]\n");
    printf("\n  -> w axis0.requested_state 3; for calib\n");
    printf("  -> w axis0.requested_state 8; closed loop\n");
    printf("--------------------------------------------------------------------------\n");
    
    for(;;)
    {
      printf("ODrive$ ");
      /* Process command line. */
      if(fgets(line, 256, stdin) != NULL)
      {
        /* Exit command line. */
        if(strcmp(line, "exit\n") == 0)
        {
          break;
        }
        /* Print new line. */
        else if(strcmp(line, "\n") == 0)
        {
          /* Do nothing. */
        }
        /* Send command to ODrive. */
        else
        {
          LibODriveSessionWriteData(line, strlen(line), line, &len);
          line[len] = 0;
          printf("%s\n", line);
        }
      }
    }
  }
  
  /* -------------------- Session stopping ------------------------------------------- */
  if (result == RESULT_OK)
  {
    /* Stop the session. */
    printf("Finishing session..."); (void)fflush(stdout);
    LibODriveSessionStop();
    printf("%s\n", GetLineTrailerByResult((bool)false));
  }

  /* -------------------- Cleanup ---------------------------------------------------- */
  /* Terminate the session. */
  LibODriveSessionTerminate();
  /* Free allocated memory */
  free(appTransportSettings);
  free(appSessionSettings);
  /* Give result back. */
  return result;
} /*** end of main ***/


/************************************************************************************//**
** \brief     Outputs information to the user about this program.
**
****************************************************************************************/
static void DisplayProgramInfo(void)
{
  printf("--------------------------------------------------------------------------\n");
  printf("ODriveTerminal version 1.04.02.\n");
  printf("libODrive version %s\n", LibODriveVersionGetString());
  printf("--------------------------------------------------------------------------\n");
} /*** end of DisplayProgramInfo ***/


/************************************************************************************//**
** \brief     Outputs information to the user about how to use this program.
**
****************************************************************************************/
static void DisplayProgramUsage(void)
{
  printf("Usage:    BootCommander [options]\n");
  printf("\n");
  printf("Example:  BootCommander -s=ascii -t=rs232 -d=COM1 -b=115200\n");
  printf("\n");
  printf("The available options depend on the specified communication session\n");
  printf("protocol and communication transport layer:\n");
  printf("  -s=[name]        Name of the communication session protocol:\n");
  printf("                     ascii (default) -> ASCII protocol\n");
  printf("  -t=[name]        Name of the communication transport layer:\n");
  printf("                     rs232 (default) -> XCP on RS232.\n");
  printf("                     can             -> XCP on CAN.\n");
  printf("                     usb             -> XCP on USB.\n");
  printf("                     net             -> XCP on TCP/IP.\n");
  printf("\n");                   
  printf("ASCII protocol settings (ascii):\n");
  printf("  -t1=[timeout]    Command response timeout in milliseconds as a 16-bit\n");
  printf("\n");  
  printf("RS232 settings (rs232):\n");
  printf("  -d=[name]        Name of the communication device. For example COM1 or\n");
  printf("                   /dev/ttyUSB0 (Mandatory).\n");
  printf("  -b=[value]       The communication speed, a.k.a baudrate in bits per\n");
  printf("                   second, as a 32-bit value (Default = 115200).\n");
  printf("                   Supported values: 9600, 19200, 38400, 57600, 115200.\n");
  printf("\n");  
  printf("CAN settings (can):\n");
  printf("  -d=[name]        Name of the CAN device (Mandatory). On Linux this is\n");
  printf("                   the name of the SocketCAN network interface, such as\n");
  printf("                   can0, slcan0. On Windows it specifies the CAN adapter.\n");
  printf("                   Currently supported CAN adapters:\n");
  printf("                     peak_pcanusb     -> Peak System PCAN-USB.\n");
  printf("                     kvaser_leaflight -> Kvaser Leaf Light V2.\n");
  printf("                     lawicel_canusb   -> Lawicel CANUSB.\n");
  printf("                     vector_xldriver  -> Vector XL Driver.\n");
  printf("  -c=[value]       Zero based index of the CAN channel if multiple CAN\n");
  printf("                   channels are supported for the CAN adapter, as a 32-\n");
  printf("                   bit value (Default = 0).\n");
  printf("  -b=[value]       The communication speed, a.k.a baudrate in bits per\n");
  printf("                   second, as a 32-bit value (Default = 500000).\n");
  printf("                   Supported values: 1000000, 800000, 500000, 250000,\n");
  printf("                   125000, 100000, 50000, 20000, 10000.\n");
  printf("  -tid=[value]     CAN identifier for transmitting XCP command messages\n");
  printf("                   from the host to the target, as a 32-bit hexadecimal\n");
  printf("                   value (Default = 667h).\n");
  printf("  -rid=[value]     CAN identifier for receiving XCP response messages\n");
  printf("                   from the target to the host, as a 32-bit hexadecimal\n");
  printf("                   value (Default = 7E1h).\n");
  printf("  -xid=[value]     Configures the 'tid' and 'rid' CAN identifier values\n");
  printf("                   as 29-bit CAN identifiers, if this 8-bit value is > 0\n");
  printf("                   (Default = 0).\n");
  printf("\n");                   
  printf("USB settings (usb):\n");
  printf("  No additional settings needed.\n");
  printf("\n");  
  printf("TCP/IP settings (net):\n");
  printf("  -a=[value]       The IP address or hostname of the target to connect to.\n");
  printf("                   For example 192.168.178.23 (Mandatory).\n");
  printf("  -p=[value]       The TCP port number to use, as a 16-bit value (Default\n");
  printf("                   = 1000).\n");
  printf("\n");
  printf("Program settings:\n");
  printf("  -sm              Silent mode switch. When specified, only minimal\n");
  printf("                   information is written to the output (Optional).\n");
  printf("\n");
  printf("Note that it is not necessary to specify an option if its default value\n");
  printf("is already the desired value.\n");
  printf("-------------------------------------------------------------------------\n");
} /*** end of DisplayProgramUsage ***/


/************************************************************************************//**
** \brief     Displays session protocol information on the standard output.
** \param     sessionType The detected session type.
** \param     sessionSettings The detected session settings.
**
****************************************************************************************/
static void DisplaySessionInfo(uint32_t sessionType, void const * sessionSettings)
{
  /* Output session protocol info. */
  printf("Detected session protocol: ");
  switch (sessionType) 
  {
    case LIBODRIVE_SESSION_ASCII:
      printf("ODrive ASCII terminal\n");
      break;
    default:
      printf("Unknown\n");
      break;
  }
  
  /* Output session settings info. */
  printf("Using session protocol settings:\n");
  switch (sessionType) 
  {
    case LIBODRIVE_SESSION_ASCII:
    {
      /* Check settings pointer. */
      assert(sessionSettings);
      if (sessionSettings == NULL) /*lint !e774 */
      {
        /* No valid settings present. */
        printf("  -> Invalid settings specified\n");
      }
      else
      {
        tLibODriveSessionSettingsAscii * settings = 
          (tLibODriveSessionSettingsAscii *)sessionSettings;
        
        /* Output the settings to the user. */
        printf("  -> Timeout: %hu ms\n", settings->timeout);
      }
      break;
    }
    default:
      printf("  -> No settings specified\n");
      break;
  }
} /*** end of DisplaySessionInfo ***/


/************************************************************************************//**
** \brief     Displays transport layer information on the standard output.
** \param     transportType The detected transport type.
** \param     transportSettings The detected transport settings.
**
****************************************************************************************/
static void DisplayTransportInfo(uint32_t transportType, void const * transportSettings)
{
  /* Output transport layer info. */
  printf("Detected transport layer: ");
  switch (transportType) 
  {
    case LIBODRIVE_TRANSPORT_RS232:
      printf("RS232\n");
      break;
    case LIBODRIVE_TRANSPORT_CAN:
      printf("CAN\n");
      break;
    case LIBODRIVE_TRANSPORT_USB:
      printf("USB\n");
      break;
    case LIBODRIVE_TRANSPORT_NET:
      printf("TCP/IP\n");
      break;
    default:
      printf("Unknown\n");
      break;
  }
  
  /* Output transport settings info. */
  printf("Using transport layer settings:\n");
  switch (transportType) 
  {
    case LIBODRIVE_TRANSPORT_RS232:
    {
      /* Check settings pointer. */
      assert(transportSettings);
      if (transportSettings == NULL) /*lint !e774 */
      {
        /* No valid settings present. */
        printf("  -> Invalid settings specified\n");
      }
      else
      {
        tLibODriveTransportSettingsRs232 * Rs232Settings = 
          (tLibODriveTransportSettingsRs232 *)transportSettings;
        
        /* Output the settings to the user. */
        printf("  -> Device: ");
        if (Rs232Settings->portName != NULL)
        {
          printf("%s\n", Rs232Settings->portName);
        }
        else
        {
          printf("Unknown\n");
        }
        printf("  -> Baudrate: %u bit/sec\n", Rs232Settings->baudrate);
      }
      break;
    }
    case LIBODRIVE_TRANSPORT_CAN:
    {
      /* Check settings pointer. */
      assert(transportSettings);
      if (transportSettings == NULL) /*lint !e774 */
      {
        /* No valid settings present. */
        printf("  -> Invalid settings specified\n");
      }
      else
      {
        tLibODriveTransportSettingsCan * CanSettings = 
          (tLibODriveTransportSettingsCan *)transportSettings;
        
        /* Output the settings to the user. */
        printf("  -> Device: ");
        if (CanSettings->deviceName != NULL)
        {
          printf("%s (channel %u)\n", CanSettings->deviceName,
                 CanSettings->deviceChannel);
        }
        else
        {
          printf("Unknown\n");
        }
        printf("  -> Baudrate: %u bit/sec\n", CanSettings->baudrate);
        printf("  -> Transmit CAN identifier: %Xh\n", CanSettings->transmitId);
        printf("  -> Receive CAN identifier: %Xh\n", CanSettings->receiveId);
        printf("  -> Use 29-bit CAN identifiers: ");
        if (CanSettings->useExtended)
        {
          printf("Yes\n");
        }
        else
        {
          printf("No\n");
        }
      }
      break;
    }
    case LIBODRIVE_TRANSPORT_USB:
    {
      printf("  -> No additional settings required.\n");
      break;
    }
    case LIBODRIVE_TRANSPORT_NET:
    {
      /* Check settings pointer. */
      assert(transportSettings);
      if (transportSettings == NULL) /*lint !e774 */
      {
        /* No valid settings present. */
        printf("  -> Invalid settings specified\n");
      }
      else
      {
        tLibODriveTransportSettingsNet * NetSettings =
          (tLibODriveTransportSettingsNet *)transportSettings;

        /* Output the settings to the user. */
        printf("  -> Address: ");
        if (NetSettings->address != NULL)
        {
          printf("%s\n", NetSettings->address);
        }
        else
        {
          printf("Unknown\n");
        }
        printf("  -> Port: %hu \n", NetSettings->port);
      }
      break;
    }
    default:
      printf("  -> No settings specified\n");
      break;
  }
} /*** end of DisplayTransportInfo ***/


/************************************************************************************//**
** \brief     Parses the command line to extract the program settings. 
** \param     argc Number of program arguments.
** \param     argv Array with program parameter strings.
** \param     programSettings Pointer to the setting structure where the program
**            settings should be written to.
**
****************************************************************************************/
static void ExtractProgramSettingsFromCommandLine(int argc, char const * const argv[],
                                                  tProgramSettings * programSettings)
{
  uint8_t paramIdx;
  
  /* Check parameters. */
  assert(argv != NULL);
  assert(programSettings != NULL);
  
  /* Only continue if parameters are valid. */
  if ( (argv != NULL) && (programSettings != NULL) ) /*lint !e774 */
  {
    /* Set default program settings. */
    programSettings->silentMode = false;
    /* Loop through all the command line parameters, just skip the 1st one because this
     * is the name of the program, which we are not interested in.
     */
    for (paramIdx = 1; paramIdx < argc; paramIdx++)
    {
      /* Is this the -sm parameter? */
      if ( (strstr(argv[paramIdx], "-sm") != NULL) &&
           (strlen(argv[paramIdx]) == 3) )
      {
        /* Activate silent mode. */
        programSettings->silentMode = true;
        /* Continue with next loop iteration. */
        continue;
      }
    }
  }
} /*** end of ExtractProgramSettingsFromCommandLine ***/


/************************************************************************************//**
** \brief     Parses the command line to extract the session type. This is the
**            one specified via the -s=[name] parameter.
** \param     argc Number of program arguments.
** \param     argv Array with program parameter strings.
** \return    The session type value as used in LibODrive.
**
****************************************************************************************/
static uint32_t ExtractSessionTypeFromCommandLine(int argc, char const * const argv[])
{
  uint32_t result;
  uint8_t paramIdx;
  uint8_t mapIdx; 
  /* Mapping of the supported session types to the session type values. */
  const struct
  {
    char * name;
    uint32_t value;
  } sessionMap[] =
  {
    { .name = "ascii",  .value = LIBODRIVE_SESSION_ASCII }
  };
  
  /*Set the default session in case nothing was specified on the command line.*/
  result = sessionMap[0].value;

  /* Check parameters. */
  assert(argv != NULL);

  /* Only continue if parameters are valid. */
  if (argv != NULL) /*lint !e774 */
  {
    /* Loop through all the command line parameters, just skip the 1st one because this
     * is the name of the program, which we are not interested in.
     */
    for (paramIdx = 1; paramIdx < argc; paramIdx++)
    {
      /* Check of the if -s is present in this argument. Note that the argument must have
       * at least 4 characters to be a valid -s=[name] parameter.
       */
      if((strstr(argv[paramIdx],"-s=") != NULL) && (strlen(argv[paramIdx]) > 3))
      {
        /* Loop through the map to find a matching session name. */
        for(mapIdx=0; mapIdx<sizeof(sessionMap)/sizeof(sessionMap[0]); mapIdx++)
        {
          /* Check for matching name. */
          if (strcmp(sessionMap[mapIdx].name, &argv[paramIdx][3]) == 0)
          {
            /* Match found, now store the associated session type value. */
            result = sessionMap[mapIdx].value;
            /* No need to continue searching. */
            break;
          }
        }
      }
    }
  }
  /* Give the result back to the caller. */
  return result;
} /*** end of ExtractSessionTypeFromCommandLine ***/


/************************************************************************************//**
** \brief     Parses the command line to extract the session settings based on the
**            specified session type. Note that this function allocates the memory
**            necessary to store the settings. It is the caller's responsibility to free
**            this memory after it is done with it.
** \param     argc Number of program arguments.
** \param     argv Array with program parameter strings.
** \param     sessionType The session type for which to extract the settings.
** \return    Pointer to the session settings structure as used in LibODrive.
**
****************************************************************************************/
static void * ExtractSessionSettingsFromCommandLine(int argc, char const * const argv[],
                                                    uint32_t sessionType)
{
  void * result = NULL;
  uint8_t paramIdx;
  
  /* Check parameters. */
  assert(argv != NULL);

  /* Only continue if parameters are valid. */
  if (argv != NULL) /*lint !e774 */
  {
    /* Filter on the session type. */
    switch (sessionType) 
    {
      /* -------------------------- ASCII -------------------------------------------- */
      case LIBODRIVE_SESSION_ASCII:
        /* The following session specific command line parameters are supported:
         *   -t1=[timeout]  -> Command response timeout in milliseconds.
         */
        /* Allocate memory for storing the settings and check the result. */
        result = malloc(sizeof(tLibODriveSessionSettingsAscii));
        assert(result != NULL);
        if (result != NULL) /*lint !e774 */
        {
          /* Create typed pointer for easy reading. */
          tLibODriveSessionSettingsAscii * asciiSettings =
            (tLibODriveSessionSettingsAscii *)result;
          /* Set default values. */
          asciiSettings->timeout = 20;
          /* Loop through all the command line parameters, just skip the 1st one because 
           * this  is the name of the program, which we are not interested in.
           */
          for (paramIdx = 1; paramIdx < argc; paramIdx++)
          {
            /* Is this the -t1=[timeout] parameter? */
            if ( (strstr(argv[paramIdx], "-t1=") != NULL) && 
                 (strlen(argv[paramIdx]) > 4) )
            {
              /* Extract the timeout value. */
              sscanf(&argv[paramIdx][4], "%hu", &(asciiSettings->timeout));
              /* Continue with next loop iteration. */
              continue;
            }
          }
        }
        break;
      /* -------------------------- Unknown --------------------------------- */
      default:
        /* Noting to extract. */
        break;
    }
  }  
  /* Give the result back to the caller. */
  return result;
} /*** end of ExtractSessionSettingsFromCommandLine ***/


/************************************************************************************//**
** \brief     Parses the command line to extract the transport type. This is the one
**            specified via the -t=[name] parameter.
** \param     argc Number of program arguments.
** \param     argv Array with program parameter strings.
** \return    The transport type value as used in LibODrive.
**
****************************************************************************************/
static uint32_t ExtractTransportTypeFromCommandLine(int argc, char const * const argv[])
{
  uint32_t result;
  uint8_t paramIdx;
  uint8_t mapIdx; 
  /* Mapping of the supported transport types to the transport type values. */
  const struct
  {
    char * name;
    uint32_t value;
  } transportMap[] =
  {
    { .name = "rs232", .value = LIBODRIVE_TRANSPORT_RS232 },
    { .name = "can",   .value = LIBODRIVE_TRANSPORT_CAN },
    { .name = "usb",   .value = LIBODRIVE_TRANSPORT_USB },
    { .name = "net",   .value = LIBODRIVE_TRANSPORT_NET }
  };
  
  /* Set the default transport type in case nothing was specified on the command line. */
  result = transportMap[0].value;
  
  /* Check parameters. */
  assert(argv != NULL);

  /* Only continue if parameters are valid. */
  if (argv != NULL) /*lint !e774 */
  {
    /* Loop through all the command line parameters, just skip the 1st one because this
     * is the name of the program, which we are not interested in.
     */
    for (paramIdx = 1; paramIdx < argc; paramIdx++)
    {
      /* Check of the if -t is present in this argument. Note that the argument must have
       * at least 4 characters to be a valid -t=[name] parameter.
       */
      if((strstr(argv[paramIdx],"-t=") != NULL) && (strlen(argv[paramIdx]) > 3))
      {
        /* Loop through the map to find a matching transport name. */
        for ( mapIdx = 0; mapIdx < sizeof(transportMap)/sizeof(transportMap[0]);
              mapIdx++)
        {
          /* Check for matching name. */
          if (strcmp(transportMap[mapIdx].name, &argv[paramIdx][3]) == 0)
          {
            /* Match found, now store the associated transport type value. */
            result = transportMap[mapIdx].value;
            /* No need to continue searching. */
            break;
          }
        }
      }
    }
  }
  /* Give the result back to the caller. */
  return result;
} /*** end of ExtractTransportTypeFromCommandLine ***/


/************************************************************************************//**
** \brief     Parses the command line to extract the transport settings based on the
**            specified session type. Note that this function allocates the memory
**            necessary to store the settings. It is the caller's responsibility to free
**            this memory after it is done with it.
** \param     argc Number of program arguments.
** \param     argv Array with program parameter strings.
** \param     transportType The transport type for which to extract the settings.
** \return    Pointer to the transport settings structure as used in LibODrive.
**
****************************************************************************************/
static void * ExtractTransportSettingsFromCommandLine(int argc,
                                                      char const * const argv[],
                                                      uint32_t transportType)
{
  void * result = NULL;
  uint8_t paramIdx;
  
  /* Check parameters. */
  assert(argv != NULL);

  /* Only continue if parameters are valid. */
  if (argv != NULL) /*lint !e774 */
  {
    /* Filter on the session type. */
    switch (transportType) 
    {
      /* --------------------------------- RS232 ------------------------------------- */
      case LIBODRIVE_TRANSPORT_RS232:
        /* The following transport layer specific command line parameters are supported:
         *   -d=[name]      -> Device name: /dev/ttyUSB0, COM1, etc.
         *   -b=[value]     -> Baudrate in bits per second.
         */
        /* Allocate memory for storing the settings and check the result. */
        result = malloc(sizeof(tLibODriveTransportSettingsRs232));
        assert(result != NULL);
        if (result != NULL) /*lint !e774 */
        {
          /* Create typed pointer for easy reading. */
          tLibODriveTransportSettingsRs232 * rs232Settings = 
            (tLibODriveTransportSettingsRs232 *)result;
          /* Set default values. */
          rs232Settings->portName = NULL;
          rs232Settings->baudrate = 115200;
          /* Loop through all the command line parameters, just skip the 1st one because
           * this  is the name of the program, which we are not interested in.
           */
          for (paramIdx = 1; paramIdx < argc; paramIdx++)
          {
            /* Is this the -d=[name] parameter? */
            if ( (strstr(argv[paramIdx], "-d=") != NULL) && 
                 (strlen(argv[paramIdx]) > 3) )
            {
              /* Store the pointer to the device name. */
              rs232Settings->portName = &argv[paramIdx][3];
              /* Continue with next loop iteration. */
              continue;
            }
            /* Is this the -b=[value] parameter? */
            if ( (strstr(argv[paramIdx], "-b=") != NULL) && 
                 (strlen(argv[paramIdx]) > 3) )
            {
              /* Extract the baudrate value. */
              sscanf(&argv[paramIdx][3], "%u", &(rs232Settings->baudrate));
              /* Continue with next loop iteration. */
              continue;
            }
          }
        }
        break;
      /* --------------------------------- CAN --------------------------------------- */
      case LIBODRIVE_TRANSPORT_CAN:
        /* The following transport layer specific command line parameters are supported:
         *   -d=[name]      -> Device name: peak_pcanusb, can0, etc.
         *   -c=[value]     -> CAN channel index (32-bit).
         *   -b=[value]     -> Baudrate in bits per second (32-bit).
         *   -tid=[value]   -> Transmit CAN identifier (32-bit hexadecimal).
         *   -rid=[value]   -> Receive CAN identifier (32-bit hexadecimal).
         *   -xid=[value]   -> Flag for configuring extended CAN identifiers
         *                     (8-bit).
         */
        /* Allocate memory for storing the settings and check the result. */
        result = malloc(sizeof(tLibODriveTransportSettingsCan));
        assert(result != NULL);
        if (result != NULL) /*lint !e774 */
        {
          /* Create typed pointer for easy reading. */
          tLibODriveTransportSettingsCan * canSettings = (tLibODriveTransportSettingsCan *)result;
          /* Set default values. */
          canSettings->deviceName = NULL;
          canSettings->deviceChannel = 0;
          canSettings->baudrate = 500000;
          canSettings->transmitId = 0x667;
          canSettings->receiveId = 0x7E1;
          canSettings->useExtended = false;
          /* Loop through all the command line parameters, just skip the 1st one because
           * this  is the name of the program, which we are not interested in.
           */
          for (paramIdx = 1; paramIdx < argc; paramIdx++)
          {
            /* Is this the -d=[name] parameter? */
            if ( (strstr(argv[paramIdx], "-d=") != NULL) && 
                 (strlen(argv[paramIdx]) > 3) )
            {
              /* Store the pointer to the device name. */
              canSettings->deviceName = &argv[paramIdx][3];
              /* Continue with next loop iteration. */
              continue;
            }
            /* Is this the -c=[value] parameter? */
            if ( (strstr(argv[paramIdx], "-c=") != NULL) && 
                 (strlen(argv[paramIdx]) > 3) )
            {
              /* Extract the channel index value. */
              sscanf(&argv[paramIdx][3], "%u", &(canSettings->deviceChannel));
              /* Continue with next loop iteration. */
              continue;
            }
            /* Is this the -b=[value] parameter? */
            if ( (strstr(argv[paramIdx], "-b=") != NULL) && 
                 (strlen(argv[paramIdx]) > 3) )
            {
              /* Extract the baudrate value. */
              sscanf(&argv[paramIdx][3], "%u", &(canSettings->baudrate));
              /* Continue with next loop iteration. */
              continue;
            }
            /* Is this the -tid=[value] parameter? */
            if ( (strstr(argv[paramIdx], "-tid=") != NULL) && 
                 (strlen(argv[paramIdx]) > 5) )
            {
              /* Extract the hexadecimal transmit CAN identifier value. */
              sscanf(&argv[paramIdx][5], "%x", &(canSettings->transmitId));
              /* Continue with next loop iteration. */
              continue;
            }
            /* Is this the -rid=[value] parameter? */
            if ( (strstr(argv[paramIdx], "-rid=") != NULL) && 
                 (strlen(argv[paramIdx]) > 5) )
            {
              /* Extract the hexadecimal receive CAN identifier value. */
              sscanf(&argv[paramIdx][5], "%x", &(canSettings->receiveId));
              /* Continue with next loop iteration. */
              continue;
            }
            /* Is this the -xid=[value] parameter? */
            if ( (strstr(argv[paramIdx], "-xid=") != NULL) && 
                 (strlen(argv[paramIdx]) > 5) )
            {
              /* Extract the extended CAN identifier configuration value. */
              static uint8_t xidValue;
              sscanf(&argv[paramIdx][5], "%hhu", &xidValue);
              /* Convert to boolean. */
              canSettings->useExtended = ((xidValue > 0) ? true : false);
              /* Continue with next loop iteration. */
              continue;
            }
          }
        }
        break;
      /* --------------------------------- USB --------------------------------------- */
      case LIBODRIVE_TRANSPORT_USB:
        /* No additional command line parameters are neede for the USB transport layer.*/
        break;
      /* --------------------------------- TCP/IP ------------------------------------ */
      case LIBODRIVE_TRANSPORT_NET:
        /* The following transport layer specific command line parameters are
         * supported:
         *   -a=[value]     -> The IP address or hostname of the target to
         *                     connect to.
         *   -p=[value]     -> The TCP port number to use.
         */
        /* Allocate memory for storing the settings and check the result. */
        result = malloc(sizeof(tLibODriveTransportSettingsNet));
        assert(result != NULL);
        if (result != NULL) /*lint !e774 */
        {
          /* Create typed pointer for easy reading. */
          tLibODriveTransportSettingsNet * netSettings = (tLibODriveTransportSettingsNet *)result;
          /* Set default values. */
          netSettings->address = NULL;
          netSettings->port = 1000;
          /* Loop through all the command line parameters, just skip the 1st one
           * because this  is the name of the program, which we are not interested in.
           */
          for (paramIdx = 1; paramIdx < argc; paramIdx++)
          {
            /* Is this the -a=[name] parameter? */
            if ( (strstr(argv[paramIdx], "-a=") != NULL) &&
                 (strlen(argv[paramIdx]) > 3) )
            {
              /* Store the pointer to the network address. */
              netSettings->address = &argv[paramIdx][3];
              /* Continue with next loop iteration. */
              continue;
            }
            /* Is this the -p=[value] parameter? */
            if ( (strstr(argv[paramIdx], "-p=") != NULL) &&
                 (strlen(argv[paramIdx]) > 3) )
            {
              /* Extract the port value. */
              sscanf(&argv[paramIdx][3], "%hu", &(netSettings->port));
              /* Continue with next loop iteration. */
              continue;
            }
          }
        }
        break;
      /* -------------------------- Unknown ------------------------------------------ */
      default:
        /* Noting to extract. */
        break;
    }
  }
  /* Give the result back to the caller. */
  return result;
} /*** end of ExtractTransportSettingsFromCommandLine ***/


/************************************************************************************//**
** \brief     Information outputted to the user sometimes has [OK] or [ERROR] appended
**            at the end. This function obtains this trailer based on the value of the
**            parameter.
** \param     errorDetected True to obtain an error trailer, false for a success trailer.
** \return    Pointer to the character array (string) with the trailer.
**
****************************************************************************************/
static char const * GetLineTrailerByResult(bool errorDetected)
{
  char const * result;
  /* Note that the following strings were declared static to guarantee that the pointers
   * stay valid and can be used by the caller of this function.
   */
  static char const * trailerStrOk = "[" OUTPUT_GREEN "OK" OUTPUT_RESET "]";
  static char const * trailerStrError = "[" OUTPUT_RED "ERROR" OUTPUT_RESET "]";

  /* Set trailer based on the error status. */  
  if (!errorDetected)
  {
    result = trailerStrOk;
  }
  else
  {
    result = trailerStrError;
  }
  /* Give the result back to the caller. */
  return result;
} /*** end of GetLineTrailerByResult ***/


/************************************************************************************//**
** \brief     Information outputted to the user sometimes has [xxx%] appended at the end.
**            This function obtains this trailer based on the value of the parameter.
** \param     percentage Percentage value (0..100) to embed in the trailer.
** \return    Pointer to the character array (string) with the trailer.
**
****************************************************************************************/
static char const * GetLineTrailerByPercentage(uint8_t percentage)
{
  char const * result;
  /* Note that the following string was declared static to guarantee that the pointer
   * stays valid and can be used by the caller of this function.
   */
  static char trailerStrPct[32] = "";

  /* Construct the trailer. */
  sprintf(trailerStrPct, "[" OUTPUT_YELLOW "%3hhu%%" OUTPUT_RESET "]", percentage);
  /* Set the result. */
  result = &trailerStrPct[0];
  /* Give the result back to the caller. */
  return result;
} /*** end of GetLineTrailerByPercentage ***/


/************************************************************************************//**
** \brief     Erases a percentage trailer from the standard ouput by means of writing
**            backspace characters.
**
****************************************************************************************/
static void ErasePercentageTrailer(void)
{
  uint32_t backspaceCnt;
  uint32_t trailerLen;
  
  trailerLen = strlen("[100%]");
  for (backspaceCnt = 0; backspaceCnt < trailerLen; backspaceCnt++)
  {
    /* Go one character back. */
    (void)putchar('\b');
    /* Overwrite it with a space. */
    (void)putchar(' ');
    /* Go one character back. */
    (void)putchar('\b');
  }
} /*** end of ErasePercentageTrailer ***/


/****************************** end of main.c ******************************************/
